/*
    iGo - Caminhos inteligentes.
    Alunos: Melyssa Mariana Gomes Silva e Antonio Emilio Pereira
    Disciplina: Estrutura de Dados II
*/

/*Variáveis*/

int escolha; /*Escolha do menu.*/
int indexInicio;    /*Indice da posição inicial.*/
int indexDestino;   /*Indice da posição final.*/
int tempoEstimado = 0;  /*Tempo estimado de deslocamento.*/
int tempoEstimadoAtual = 0;
char *condicao; /*Condição atual do transito*/
char *nomeLocal;    /*Nome inserido pelo usuário do lugar de partida*/
char *nomeDestino;  /*Nome inserido pelo usuário do lugar de destino*/
int valorASCIIDestino;  /*Valor em ASCII do local de destino*/

